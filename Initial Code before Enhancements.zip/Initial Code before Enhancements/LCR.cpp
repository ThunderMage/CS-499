// LCR Current Progress:


#include "Implementation.h"

#include <iostream>
#include <vector>
#include <random>
#include <string>


using namespace std;



// Main method
int main() {

	Implementation game;

	game.showRules();

	int playerInput = 0; // Initialize the starting number of players to zero.
	bool validChoice = false; // Initialize variable for whether input is valid. 

	// Determine number of players in the game. 
	game.GetPlayerInput(&playerInput, validChoice);

	int curPlayers = playerInput; // Initialize the number of players still in the game. 

	// Create 2d vector to store each of the players' scores
	vector<vector<int>> players;

	// Populate each vector element based on the number of players
	for (int k = 0; k < curPlayers; k++)
	{
		vector<int> temp;
		for (int q = 3; q < 4; q++)
		{
			temp.push_back(q);
		}
		players.push_back(temp);
	}

	game.print_scores(players);

	// Die roller
	random_device rd; // Obtain a random number from hardware
	mt19937 gen(rd()); // Seed the generator
	uniform_int_distribution<> distr(1, 6); // Define the range
	int dieRoll;


	// Player turns 
	do
	{

		for (int i = 0; i < curPlayers; i++)
		{

			// Declare whose turn it is
			cout << endl << "-------------" << endl << "It is player  " << i + 1 << "'s turn" << endl;

			// Determine how many dice will be rolled
			if (players[i][0] <= 3)
			{
				cout << "\nPlayer " << i + 1 << " has " << players[i][0] << " chips, " << endl << "so " << players[i][0] << " dice will be rolled." << endl << endl;
			
				// Roll number of dice based on current score
				for (int j = 0; j < players[i][0]; j++) // Reminder: the 'players' vector stores the players' scores.
				{
					// Roll die
					dieRoll = distr(gen);

					// Pass a chip to the left player if the die rolls a 1.
					if (dieRoll == 1)
					{
						// If it is player 1's turn, dice they pass left will go to the last player.
						if (i == 0)
						{
							players[i][0] = players[i][0] - 1; // Current player loses a chip
							players[curPlayers][0] = players[curPlayers][0] + 1; // Last player gains a chip
						}

						// If it is any other player's turn, dice passing will be normal.
						else
						{
							players[i][0] = players[i][0] - 1; // Current player loses a chip.
							players[i - 1][0] = players[i - 1][0] + 1; // Previous player gains a chip.
						}
						cout << "Player " << i + 1 << " rolled a 1 so they give a chip to the previous (or last) player." << endl;
					}

					// Pass a chip to the right player if the die rolls a 2.
					else if (dieRoll == 2) {

						// If it is the last player's turn, dice they pass right will go to player 1.
						if (i == curPlayers)
						{
							players[i][0] = players[i][0] - 1; // Current player loses a chip.
							players[0][0] = players[0][0] + 1; // First player gains a chip.
						}

						else
						{
							players[i][0] = players[i][0] - 1; // Current player loses a chip.
							players[i + 1][0] = players[i + 1][0] + 1; // Next player gains a chip.
						}
						cout << "Player " << i + 1 << " rolled a 2 so they give a chip to the next player." << endl;
					}

					// Remove a chip from current player if a 3 is rolled.
					else if (dieRoll == 3) {

						// If it is the last player's turn, dice they pass right will go to player 1.
						if (i == curPlayers)
						{
							players[i][0] = players[i][0] - 1; // Current player loses a chip.
						}
						cout << "Player " << i + 1 << " rolled a 3 so they lose a chip." << endl;

					}

					// Nothing happens if the current player does not roll a 1, 2, or 3.
					else
					{
						cout << "Player " << i + 1 << " did not roll a 1, 2, or 3 so nothing happens." << endl;
					}
				}
			}

			else
			{
				cout << "\nPlayer " << i + 1 << " has " << players[i][0] << " chips, " << endl << "so " << 3 << " dice will be rolled." << endl << endl;
			
				// Roll number of dice based on current score
				for (int j = 0; j < 3; j++) // Reminder: the 'players' vector stores the players' scores.
				{
					// Roll die
					dieRoll = distr(gen);

					// Pass a chip to the left player if the die rolls a 1.
					if (dieRoll == 1)
					{
						// If it is player 1's turn, dice they pass left will go to the last player.
						if (i == 0)
						{
							players[i][0] = players[i][0] - 1; // Current player loses a chip
							players[curPlayers][0] = players[curPlayers][0] + 1; // Last player gains a chip
						}

						// If it is any other player's turn, dice passing will be normal.
						else
						{
							players[i][0] = players[i][0] - 1; // Current player loses a chip.
							players[i - 1][0] = players[i - 1][0] + 1; // Previous player gains a chip.
						}
						cout << "Player " << i + 1 << " rolled a 1 so they give a chip to the previous (or last) player." << endl;
					}

					// Pass a chip to the right player if the die rolls a 2.
					if (dieRoll == 2) {

						// If it is the last player's turn, dice they pass right will go to player 1.
						if (i == curPlayers)
						{
							players[i][0] = players[i][0] - 1; // Current player loses a chip.
							players[0][0] = players[0][0] + 1; // First player gains a chip.
						}

						else
						{
							players[i][0] = players[i][0] - 1; // Current player loses a chip.
							players[i + 1][0] = players[i + 1][0] + 1; // Next player gains a chip.
						}
						cout << "Player " << i + 1 << " rolled a 2 so they give a chip to the next player." << endl;
					}

					// Remove a chip from current player if a 3 is rolled.
					if (dieRoll == 3) {

						// If it is the last player's turn, dice they pass right will go to player 1.
						if (i == curPlayers)
						{
							players[i][0] = players[i][0] - 1; // Current player loses a chip.
						}
						cout << "Player " << i + 1 << " rolled a 3 so they lose a chip." << endl;

					}

					// Nothing happens if the current player does not roll a 1, 2, or 3.
					if (dieRoll != 1 && dieRoll != 2 && dieRoll != 3)
					{
						cout << "Player " << i + 1 << " did not roll a 1, 2, or 3 so nothing happens." << endl;
					}
				}
			}
			

			game.pause();

			// Delete vector element if element equals 0 (remove player from game if they have 0 chips).
			// If a player has 0 chips, remove player from game and shift following players up. 
			for (int h = 0; h < curPlayers; h++)
			{
				if (players[h][0] == 0)
				{
					for (int j = h; j < (curPlayers - 1); j++)
					{
						players[j][0] = players[j + 1][0];
					}

					h--;
					curPlayers--;

					// Print new status of player scores.
					cout << "\nPlayer " << h + 1 << " has zero chips." << endl
						<< "Player " << h + 1 << " shall be removed from the game." << endl
						<< "Player " << h + 2 << " is now Player " << h + 1 << ", " << endl
						<< "Player " << h + 3 << " is now Player " << h + 2 << ", and so on." << endl
						<< "The current number of players remaining is now " << curPlayers << "." << endl;

					game.pause();
				}

			}

			cout << "-------------" << endl;

			// Display all players' scores
			for (int h = 0; h < players.size(); h++)
			{
				for (int j = 0; j < players[h].size(); j++)
				{
					cout << "Player " << h + 1 << "'s score:" << players[h][0] << endl;

				}
			}
			game.pause();
		}
	} while (curPlayers > 1);

	cout << "\nThere is only one player remaining. The game shall now terminate." << endl;




	return 0;
}