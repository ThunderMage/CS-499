#include "Implementation.h"

#include <iostream>
#include <vector>
#include <random>
#include <string>
#include <fstream>

using namespace std;

// Void function for allowing the user to press a key to continue
void Implementation::pause()
{
	cout << "Press <enter> to continue" << endl;
	cin.clear();
	std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
}

// Void function for printing the players' current scores
void Implementation::print_scores(const vector<vector<int>>& players)
{
	cout << "The following numbers are the players' scores;" << endl
		<< "The first value is Player 1's score, the second is Player 2's, and so on:" << endl;

	for (auto row_obj : players)
	{
		for (auto elem : row_obj)
		{
			cout << elem << " ";
		}
		cout << endl;
	}
	cout << endl;
}

// Void method which receives the user's input
void Implementation::GetPlayerInput(int* playerInput, bool validChoice)
{
	validChoice = false; // Initialize the variabel representing the validity of the player's input to false.

	// Ask the user to input a valid number of starting players.
	cout << "\nWelcome to Left Center Right, or LCR." << endl
		<< "Please enter an integer between 2 and 5 for the starting number of players." << endl << endl;


	do
	{
		cin >> *playerInput; // Player inputs the value to be stored at playerInput's location.
		cout << endl << endl;

		// Only allow inputs between 2 and 9.
		if (*playerInput >= 2 && *playerInput <= 5)
		{
			validChoice = true;
		}

		else
		{
			cout << "Invalid input, try again." << endl << endl;
			cin.clear();
			cin.ignore();
		}
	} while (validChoice == false);
}

void Implementation::showRules()
{
	fstream newfile;

	newfile.open("LCRrules.txt", ios::in); //open a file to perform read operation using file object

	if (newfile.is_open()) {   //checking whether the file is open
		string tp;
		while (getline(newfile, tp)) {  //read data from file object and put it into string.
			cout << tp << "\n";   //print the data of the string
		}
		newfile.close();   //close the file object.
	}
}
































