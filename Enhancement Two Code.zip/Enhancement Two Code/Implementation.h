#pragma once

#include<vector>

using namespace std;

// Implementation class
class Implementation
{
public:
	void pause();
	void print_scores(const vector<vector<int>>& players);
	void GetPlayerInput(int* playerInput, bool validChoice);
	void rollSequence(int dieRoll, int i, vector<vector<int>> &z, int curPlayers);
	// int die_roller(random_device* rd, mt19937* gen, uniform_int_distribution<>* distr);
	//void showRules();
};