#include "Implementation.h"

#include <iostream>
#include <vector>
#include <random>
#include <string>
#include <fstream>

using namespace std;

// Void function for allowing the user to press a key to continue
void Implementation::pause()
{
	cout << "Press <enter> to continue" << endl;
	cin.clear();
	std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
}

// Void function for printing the players' current scores
void Implementation::print_scores(const vector<vector<int>>& players)
{
	cout << "The following numbers are the players' scores;" << endl
		<< "The first value is Player 1's score, the second is Player 2's, and so on:" << endl;

	for (auto row_obj : players)
	{
		for (auto elem : row_obj)
		{
			cout << elem << " ";
		}
		cout << endl;
	}
	cout << endl;
}

// Void method which receives the user's input
void Implementation::GetPlayerInput(int* playerInput)
{
	bool validChoice = false; // Initialize the variable representing the validity of the player's input to false.

	// Ask the user to input a valid number of starting players.
	cout << "Please enter an integer between 2 and 5 for the starting number of players." << endl << endl;

	do
	{
		cin >> *playerInput; // Player inputs the value to be stored at playerInput's location.
		cout << endl << endl;

		// Only allow inputs between 2 and 5.
		if (*playerInput >= 2 && *playerInput <= 5)
		{
			validChoice = true;
		}

		else
		{
			cout << "Invalid input, try again." << endl << endl;
			cin.clear();
			cin.ignore();
		}
	} while (validChoice == false);
}

void Implementation::rollSequence(int dieRoll, int i, vector<vector<int>> &z, int curPlayers)
{
	// Pass a chip to the left player if the die rolls a 1.
	if (dieRoll == 1)
	{
		// If it is player 1's turn, dice they pass left will go to the last player.
		if (i == 0)
		{
			z[i][0] = z[i][0] - 1; // Current player loses a chip
			z[curPlayers - 1][0] = z[curPlayers - 1][0] + 1; // Last player gains a chip
		}

		// If it is any other player's turn, dice passing will be normal.
		else
		{
			z[i][0] = z[i][0] - 1; // Current player loses a chip.
			z[i - 1][0] = z[i - 1][0] + 1; // Previous player gains a chip.
		}
		cout << "Player " << i + 1 << " rolled a 1 so they give a chip to the previous (or last) player." << endl;
	}

	// Pass a chip to the right player if the die rolls a 2.
	else if (dieRoll == 2) {

		// If it is the last player's turn, dice they pass right will go to player 1.
		if (i == curPlayers - 1)
		{
			z[i][0] = z[i][0] - 1; // Current player loses a chip.
			z[0][0] = z[0][0] + 1; // First player gains a chip.
		}

		else
		{
			z[i][0] = z[i][0] - 1; // Current player loses a chip.
			z[i + 1][0] = z[i + 1][0] + 1; // Next player gains a chip.
		}
		cout << "Player " << i + 1 << " rolled a 2 so they give a chip to the next player." << endl;
	}

	// Remove a chip from current player if a 3 is rolled.
	else if (dieRoll == 3) {

		z[i][0] = z[i][0] - 1; // Current player loses a chip.

		cout << "Player " << i + 1 << " rolled a 3 so they lose a chip." << endl;

	}

	// Nothing happens if the current player does not roll a 1, 2, or 3.
	else
	{
		cout << "Player " << i + 1 << " did not roll a 1, 2, or 3 so nothing happens." << endl;
	}

}

// Void method which receives the user's input.
void Implementation::login()
{
	bool validPassword = false; // Initialize the variable representing the validity of the player's input to false.
	string password; // Initialize the variable into which the user will enter the password.

	// Ask the user to input a valid number of starting players.
	cout << "\nWelcome to Left Center Right, or LCR." << endl
		<< "Please enter the correct password in order to begin the game." << endl << endl;

	do
	{
		cin >> password; // Player inputs the value to be stored at playerInput's location.
		cout << endl << endl;

		// Only allow input to be the correct password.
		if (password == "dicegame")
		{
			validPassword = true;
		}

		else
		{
			cout << "Invalid password, try again." << endl << endl;
			cin.clear();
			cin.ignore();
		}
	} while (validPassword == false);
}


































