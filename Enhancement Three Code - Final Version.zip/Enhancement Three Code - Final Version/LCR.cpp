

#include "Implementation.h"

#include <iostream>
#include <vector>
#include <random>
#include <string>
#include <fstream>


using namespace std;



// Main method
int main() {

	Implementation game;

	int playerInput = 0; // Initialize the starting number of players to zero. 

	// Ask the user to enter the correct password.
	game.login();

	// Determine number of players in the game. 
	game.GetPlayerInput(&playerInput);

	int curPlayers = playerInput; // Initialize the number of players still in the game. 

	// Create 2d vector to store the players' scores during each turn.
	vector<vector<int>> players;

	// Populate each vector element based on the number of players
	for (int k = 0; k < curPlayers; k++)
	{
		vector<int> temp;
		for (int q = 3; q < 4; q++)
		{
			temp.push_back(q);
		}
		players.push_back(temp);
	}

	// Create 2d vector to temporarily store players' scores after each die roll.
	vector<vector<int>> scores = players;



	game.print_scores(players);

	// Die roller
	random_device rd; // Obtain a random number from hardware
	mt19937 gen(rd()); // Seed the generator
	uniform_int_distribution<> distr(1, 6); // Define the range
	int dieRoll;
	// A random number between 1 and 6 is generated every time dieRoll = distr(gen) is called.
	// This simulates rolling a six-sided die.


	// Player turns 
	do
	{

		for (int i = 0; i < curPlayers; i++)
		{

			// Declare whose turn it is
			cout << endl << "-------------" << endl << "It is player  " << i + 1 << "'s turn" << endl;

			// Determine how many dice will be rolled
			if (scores[i][0] <= 3)
			{
				cout << "\nPlayer " << i + 1 << " has " << scores[i][0] << " chips, " << endl << "so " << scores[i][0] << " dice will be rolled." << endl << endl;

				// Roll number of dice based on current score
				// Reminder: the 'scores' vector stores the players' scores outside the dice roll loop. 'players' stores the players' scores within the dice roll loop.
				for (int j = 0; j < scores[i][0]; j++)
				{
					// Roll die
					dieRoll = distr(gen);

					game.rollSequence(dieRoll, i, players, curPlayers);
				}
			}

			// If player's score is greater than 3
			else 
			{
				cout << "\nPlayer " << i + 1 << " has " << scores[i][0] << " chips, " << endl << "so " << 3 << " dice will be rolled." << endl << endl;

				// Roll number of dice based on current score
				for (int j = 0; j < 3; j++) // Reminder: the 'players' vector stores the players' scores.
				{
					// Roll die
					dieRoll = distr(gen);

					game.rollSequence(dieRoll, i, players, curPlayers);
				}
			}

			// Update players's scores outside the dice roll loop
			scores = players;

			game.pause();

			// Delete vector element if element is less than 1 (remove player from game if they have 0 chips).
			// If a player has 0 chips, remove player from game and shift following players up. 
			for (int h = 0; h < curPlayers; h++)
			{
				if (scores[h][0] < 1)
				{
					for (int j = h; j < (curPlayers - 1); j++)
					{
						scores[j][0] = scores[j + 1][0];
						scores[j + 1][0] = 0;
					}


					// Print new status of player scores.
					cout << "\nPlayer " << h + 1 << " has 0 chips." << endl
						<< "Player " << h + 1 << " shall be removed from the game." << endl << endl
						<< "Player " << h + 2 << " is now Player " << h + 1 << "," << endl
						<< "Player " << h + 3 << " (if there is one) is now Player " << h + 2 << ", and so on." << endl
						<< "The current number of players remaining is now " << curPlayers - 1 << "." << endl;

					h--;
					curPlayers--;
					i--;
					players = scores;
					game.pause();
				}

			}

			cout << "-------------" << endl;

			// Display all players' scores
			for (int h = 0; h < scores.size(); h++)
			{
				for (int j = 0; j < scores[h].size(); j++)
				{
					cout << "Player " << h + 1 << "'s score:" << scores[h][0] << endl;

				}
			}
			game.pause();

			if (curPlayers <= 1) {
				break;
			}
		}
	} while (curPlayers > 1);

	cout << "\nThere is only one player remaining. The game shall now terminate." << endl;




	return 0;
}